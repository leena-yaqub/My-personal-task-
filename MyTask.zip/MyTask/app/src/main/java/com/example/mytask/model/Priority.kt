package com.example.mytask.model

enum class Priority { HIGH, MEDIUM, LOW }
